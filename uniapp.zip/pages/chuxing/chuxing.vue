<template>
	<view>
		<div>
			<image src="../../static/img/qq.png"></image>
		</div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
