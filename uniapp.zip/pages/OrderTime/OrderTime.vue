<template>
	<view class="OrderTime">
	    <van-cell title="展示弹出层" is-link bind:click="showPopup" />
	    
	    <van-popup :show="{{ show }}" bind:close="onClose">内容</van-popup>
	  </view>
</template>
<script>
export default {
  name: 'OrderTime',
    data: {
      show: false,
    },
  
    showPopup() {
      this.setData({ show: true });
    },
  
    onClose() {
      this.setData({ show: false });
    },
  });
  }
</script>

<style>
</style>
